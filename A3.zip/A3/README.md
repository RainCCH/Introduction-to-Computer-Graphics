# A3: Puppets

## Compile

Same compilation as A2 and A1.

`premake4 gmake`

`make`

This is tested by the Virtual Machine provided by the TAs. I am using a Macbook with a silicon chip.

## Result
![Screenshot](./screenshot.png "The screenshot of the app")