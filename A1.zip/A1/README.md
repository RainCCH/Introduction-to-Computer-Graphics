# Compilation of A1

`premake4 gmake`

`make`

This is tested by the Virtual Machine provided by the TAs. I am using a Macbook with silicon chip.

## Rules
Players can change the colour of the floor, avatar and the cubes(walls of the maze) using the colour editor. After tuning the colour to what you want, press the corresponding button of the object.

Press D to dig the maze(open the game).
Press R to reset the whole game to its initial state.
Press Q to exit the game.

You can rotate the maze using you mouse. You can also zoom in or zoom out while scrolling your mouse.

You can crash the walls while holding shift on your keyboard.